﻿define("epi-languagemanager/ModuleSettings", [],
    function () {

        // module:
        //      epi-languagemanager/ModuleSettings
        // summary:
        //      Module settings for EPiServer LanguageManager.
        //      Stores shared settings, constants for entire module.
        // tags:
        //      public

        return {
        };

    });
